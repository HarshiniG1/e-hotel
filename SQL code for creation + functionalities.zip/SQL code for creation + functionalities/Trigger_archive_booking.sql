-- FUNCTION: public.archive_booking()

-- DROP FUNCTION IF EXISTS public.archive_booking();

CREATE OR REPLACE FUNCTION public.archive_booking()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
BEGIN
    INSERT INTO public.booking_archive (
        archived_booking_id,
        customer_name,
        room_info,
        hotel_info,
        booking_date,
        start_date,
        end_date,
        status
    )
    SELECT
        OLD.booking_id,
        c.full_name,
        'Room ID: ' || r.room_id || ', Capacity: ' || r.capacity || ', Price: $' || r.price,
        h.hotel_name,
        CURRENT_DATE,
        OLD.start_date,
        OLD.end_date,
        OLD.status
    FROM public.customer c
    JOIN public.room r 
        ON r.room_id = OLD.room_id
    JOIN public.hotel h 
        ON h.hotel_id = OLD.hotel_id
    WHERE c.customer_id = OLD.customer_id;

    RETURN OLD;
END;
$BODY$;

ALTER FUNCTION public.archive_booking()
    OWNER TO chessinah;
