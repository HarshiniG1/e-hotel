-- QUERY 3: Rooms that are NOT currently booked (NESTED)
SELECT *
FROM room
WHERE room_id NOT IN (
    SELECT room_id
    FROM booking
    WHERE CURRENT_DATE BETWEEN start_date AND end_date
);