-- FUNCTION: public.check_booking_overlap()

-- DROP FUNCTION IF EXISTS public.check_booking_overlap();

CREATE OR REPLACE FUNCTION public.check_booking_overlap()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM booking
        WHERE room_id = NEW.room_id
          AND NEW.start_date < end_date
          AND NEW.end_date > start_date
    ) THEN
        RAISE EXCEPTION 'Room already booked for these dates';
    END IF;

    RETURN NEW;
END;
$BODY$;

ALTER FUNCTION public.check_booking_overlap()
    OWNER TO chessinah;
