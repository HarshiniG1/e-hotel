-- Table: public.room

-- DROP TABLE IF EXISTS public.room;

CREATE TABLE IF NOT EXISTS public.room
(
    room_id integer NOT NULL DEFAULT nextval('room_room_id_seq'::regclass),
    hotel_id integer NOT NULL,
    price double precision NOT NULL,
    capacity character varying(255) COLLATE pg_catalog."default" NOT NULL,
    sea_view boolean DEFAULT false,
    mountain_view boolean DEFAULT false,
    extendable boolean DEFAULT false,
    problems_description character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT room_pkey PRIMARY KEY (room_id),
    CONSTRAINT room_hotel_id_fkey FOREIGN KEY (hotel_id)
        REFERENCES public.hotel (hotel_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT room_price_check CHECK (price >= 0::numeric::double precision)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.room
    OWNER to chessinah;
-- Index: idx_room_price

-- DROP INDEX IF EXISTS public.idx_room_price;

CREATE INDEX IF NOT EXISTS idx_room_price
    ON public.room USING btree
    (price ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;