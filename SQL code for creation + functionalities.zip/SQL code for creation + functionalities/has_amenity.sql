-- Table: public.has_amenity

-- DROP TABLE IF EXISTS public.has_amenity;

CREATE TABLE IF NOT EXISTS public.has_amenity
(
    room_id integer NOT NULL,
    room_amenity_id integer NOT NULL,
    CONSTRAINT has_amenity_pkey PRIMARY KEY (room_id, room_amenity_id),
    CONSTRAINT has_amenity_room_amenity_id_fkey FOREIGN KEY (room_amenity_id)
        REFERENCES public.room_amenity (room_amenity_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT has_amenity_room_id_fkey FOREIGN KEY (room_id)
        REFERENCES public.room (room_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.has_amenity
    OWNER to chessinah;