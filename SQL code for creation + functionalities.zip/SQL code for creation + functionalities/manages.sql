-- Table: public.manages

-- DROP TABLE IF EXISTS public.manages;

CREATE TABLE IF NOT EXISTS public.manages
(
    hotel_id integer NOT NULL,
    employee_id integer,
    CONSTRAINT manages_pkey PRIMARY KEY (hotel_id),
    CONSTRAINT manages_employee_id_key UNIQUE (employee_id),
    CONSTRAINT manages_employee_id_fkey FOREIGN KEY (employee_id)
        REFERENCES public.employee (employee_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT manages_hotel_id_fkey FOREIGN KEY (hotel_id)
        REFERENCES public.hotel (hotel_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.manages
    OWNER to postgres;

GRANT ALL ON TABLE public.manages TO chessinah;

GRANT ALL ON TABLE public.manages TO postgres;