-- QUERY 4: Find all bookings for a specific area (JOIN + filter)
SELECT b.booking_id, h.address, b.start_date, b.end_date
FROM booking b
JOIN room r ON b.room_id = r.room_id
JOIN hotel h ON r.hotel_id = h.hotel_id
WHERE h.address = 'Toronto';