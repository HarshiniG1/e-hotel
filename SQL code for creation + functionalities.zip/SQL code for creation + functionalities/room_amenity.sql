-- Table: public.room_amenity

-- DROP TABLE IF EXISTS public.room_amenity;

CREATE TABLE IF NOT EXISTS public.room_amenity
(
    room_amenity_id integer NOT NULL DEFAULT nextval('room_amenity_room_amenity_id_seq'::regclass),
    name text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT room_amenity_pkey PRIMARY KEY (room_amenity_id),
    CONSTRAINT room_amenity_name_key UNIQUE (name)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.room_amenity
    OWNER to chessinah;