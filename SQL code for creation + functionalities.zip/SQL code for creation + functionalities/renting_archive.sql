-- Table: public.renting_archive

-- DROP TABLE IF EXISTS public.renting_archive;

CREATE TABLE IF NOT EXISTS public.renting_archive
(
    archived_renting_id integer NOT NULL,
    customer_name character varying(100) COLLATE pg_catalog."default",
    room_info character varying(100) COLLATE pg_catalog."default",
    hotel_info character varying(100) COLLATE pg_catalog."default",
    renting_date date,
    start_date date,
    end_date date,
    status character varying(20) COLLATE pg_catalog."default",
    employee_name character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT renting_archive_pkey PRIMARY KEY (archived_renting_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.renting_archive
    OWNER to chessinah;