-- QUERY 1: List all rooms with their hotel name (JOIN)
SELECT r.room_id, r.capacity, h.hotel_name
FROM room r
JOIN hotel h ON r.hotel_id = h.hotel_id;