-- Table: public.booking

-- DROP TABLE IF EXISTS public.booking;

CREATE TABLE IF NOT EXISTS public.booking
(
    booking_id integer NOT NULL DEFAULT nextval('booking_booking_id_seq'::regclass),
    customer_id integer NOT NULL,
    hotel_id integer NOT NULL,
    room_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT booking_pkey PRIMARY KEY (booking_id),
    CONSTRAINT booking_customer_id_fkey FOREIGN KEY (customer_id)
        REFERENCES public.customer (customer_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.booking
    OWNER to postgres;

GRANT ALL ON TABLE public.booking TO chessinah;

GRANT ALL ON TABLE public.booking TO postgres;
-- Index: idx_booking_dates

-- DROP INDEX IF EXISTS public.idx_booking_dates;

CREATE INDEX IF NOT EXISTS idx_booking_dates
    ON public.booking USING btree
    (start_date ASC NULLS LAST, end_date ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;

-- Trigger: trg_archive_booking

-- DROP TRIGGER IF EXISTS trg_archive_booking ON public.booking;

CREATE OR REPLACE TRIGGER trg_archive_booking
    BEFORE DELETE
    ON public.booking
    FOR EACH ROW
    EXECUTE FUNCTION public.archive_booking();

-- Trigger: trg_check_booking_overlap

-- DROP TRIGGER IF EXISTS trg_check_booking_overlap ON public.booking;

CREATE OR REPLACE TRIGGER trg_check_booking_overlap
    BEFORE INSERT
    ON public.booking
    FOR EACH ROW
    EXECUTE FUNCTION public.check_booking_overlap();