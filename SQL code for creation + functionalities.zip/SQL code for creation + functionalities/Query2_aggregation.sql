-- QUERY 2: Total number of rooms per hotel (AGGREGATION)
SELECT h.hotel_name, COUNT(r.room_id) AS total_rooms
FROM hotel h
JOIN room r ON h.hotel_id = r.hotel_id
GROUP BY h.hotel_name;