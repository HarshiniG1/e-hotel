-- View: public.hotel_total_capacity

-- DROP VIEW public.hotel_total_capacity;

CREATE OR REPLACE VIEW public.hotel_total_capacity
 AS
 SELECT h.hotel_id,
    h.hotel_name,
    count(r.room_id) AS total_rooms
   FROM hotel h
     JOIN room r ON h.hotel_id = r.hotel_id
  GROUP BY h.hotel_id, h.hotel_name;

ALTER TABLE public.hotel_total_capacity
    OWNER TO chessinah;

