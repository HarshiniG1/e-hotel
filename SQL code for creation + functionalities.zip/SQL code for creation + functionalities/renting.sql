-- Table: public.renting

-- DROP TABLE IF EXISTS public.renting;

CREATE TABLE IF NOT EXISTS public.renting
(
    renting_id integer NOT NULL DEFAULT nextval('renting_renting_id_seq'::regclass),
    customer_id integer NOT NULL,
    hotel_id integer NOT NULL,
    room_id integer NOT NULL,
    employee_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    payment_status boolean,
    CONSTRAINT renting_pkey PRIMARY KEY (renting_id),
    CONSTRAINT renting_customer_id_fkey FOREIGN KEY (customer_id)
        REFERENCES public.customer (customer_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT renting_employee_id_fkey FOREIGN KEY (employee_id)
        REFERENCES public.employee (employee_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.renting
    OWNER to postgres;

GRANT ALL ON TABLE public.renting TO chessinah;

GRANT ALL ON TABLE public.renting TO postgres;