-- Table: public.hotel_chain

-- DROP TABLE IF EXISTS public.hotel_chain;

CREATE TABLE IF NOT EXISTS public.hotel_chain
(
    chain_id integer NOT NULL DEFAULT nextval('hotel_chain_chain_id_seq'::regclass),
    name text COLLATE pg_catalog."default" NOT NULL,
    central_office_address text COLLATE pg_catalog."default" NOT NULL,
    email text COLLATE pg_catalog."default",
    phone text COLLATE pg_catalog."default",
    number_of_hotels integer,
    CONSTRAINT hotel_chain_pkey PRIMARY KEY (chain_id),
    CONSTRAINT hotel_chain_number_of_hotels_check CHECK (number_of_hotels >= 0)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.hotel_chain
    OWNER to chessinah;