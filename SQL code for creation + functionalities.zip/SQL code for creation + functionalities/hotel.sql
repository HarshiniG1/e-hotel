-- Table: public.hotel

-- DROP TABLE IF EXISTS public.hotel;

CREATE TABLE IF NOT EXISTS public.hotel
(
    hotel_id integer NOT NULL DEFAULT nextval('hotel_hotel_id_seq'::regclass),
    chain_id integer NOT NULL,
    hotel_name text COLLATE pg_catalog."default" NOT NULL,
    address text COLLATE pg_catalog."default" NOT NULL,
    category integer,
    number_of_rooms integer,
    email text COLLATE pg_catalog."default",
    phone text COLLATE pg_catalog."default",
    CONSTRAINT hotel_pkey PRIMARY KEY (hotel_id),
    CONSTRAINT hotel_chain_id_fkey FOREIGN KEY (chain_id)
        REFERENCES public.hotel_chain (chain_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT hotel_category_check CHECK (category >= 1 AND category <= 5),
    CONSTRAINT hotel_number_of_rooms_check CHECK (number_of_rooms >= 0)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.hotel
    OWNER to chessinah;
-- Index: idx_hotel_address

-- DROP INDEX IF EXISTS public.idx_hotel_address;

CREATE INDEX IF NOT EXISTS idx_hotel_address
    ON public.hotel USING btree
    (address COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;