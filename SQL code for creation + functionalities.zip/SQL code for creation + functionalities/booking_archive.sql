-- Table: public.booking_archive

-- DROP TABLE IF EXISTS public.booking_archive;

CREATE TABLE IF NOT EXISTS public.booking_archive
(
    archived_booking_id integer NOT NULL,
    customer_name character varying(100) COLLATE pg_catalog."default",
    room_info character varying(100) COLLATE pg_catalog."default",
    hotel_info character varying(100) COLLATE pg_catalog."default",
    booking_date date,
    start_date date,
    end_date date,
    status character varying(20) COLLATE pg_catalog."default",
    CONSTRAINT booking_archive_pkey PRIMARY KEY (archived_booking_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.booking_archive
    OWNER to chessinah;