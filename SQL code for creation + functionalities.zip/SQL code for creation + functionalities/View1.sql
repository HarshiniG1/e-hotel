-- View: public.available_rooms_per_area

-- DROP VIEW public.available_rooms_per_area;

CREATE OR REPLACE VIEW public.available_rooms_per_area
 AS
 SELECT h.address,
    count(r.room_id) AS available_rooms
   FROM hotel h
     JOIN room r ON h.hotel_id = r.hotel_id
  WHERE NOT (r.room_id IN ( SELECT booking.room_id
           FROM booking
          WHERE CURRENT_DATE >= booking.start_date AND CURRENT_DATE <= booking.end_date))
  GROUP BY h.address;

ALTER TABLE public.available_rooms_per_area
    OWNER TO chessinah;

